#!/usr/bin/env python3
import rospy
from std_msgs.msg import Int32

class Class_pub:
    def __init__(self):
        rospy.init_node("wego_pub_node") #1. node 이름 설정
        self.pub = rospy.Publisher("counter",Int32,queue_size=1) #2. node의 역할 설정
        self.rate = rospy.Rate(2) #4. 주기 설정
        self.msg = Int32()
        self.num = 0

    def run(self):
        while not rospy.is_shutdown():
            self.num=self.num+1
            self.msg.data = self.num
            self.pub.publish(self.msg) #3. publisher - publish
            self.rate.sleep() # 4-1. 주기대로 실행
            print(self.msg)

class_pub = Class_pub()
class_pub.run()