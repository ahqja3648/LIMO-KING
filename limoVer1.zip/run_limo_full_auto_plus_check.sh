#!/bin/bash
YELLOW='\033[1;33m'
GREEN='\033[1;32m'
RED='\033[1;31m'
NC='\033[0m'

echo -e "\n🚗 ===== LIMO 자동 점검 시작 ====="

if rostopic list >/dev/null 2>&1; then
    echo -e "${GREEN}✅ roscore 연결 정상${NC}"
else
    echo -e "${RED}⚠️ roscore 미실행 → 자동 실행 시도 중...${NC}"
    roscore > /dev/null 2>&1 &
    sleep 3
fi

if python3 -m pip show pylimo >/dev/null 2>&1; then
    echo -e "${GREEN}✅ pylimo 설치됨${NC}"
else
    echo -e "${RED}❌ pylimo 미설치${NC}"
    echo "→ 'pip install pylimo' 명령으로 설치 필요"
    exit 1
fi

echo -e "\n✅ 시스템 점검 완료 — 자율주행 실행으로 전환..."
sleep 2

source ~/catkin_ws/devel/setup.bash
roslaunch limo_navigation navigation_full.launch &
sleep 5
roslaunch limo_description display.launch &
sleep 3

echo -e "\n📊 실행 중 노드 목록:"
rosnode list

echo -e "\n🧭 /cmd_vel 신호 미리보기 (5초):"
timeout 5 rostopic echo /cmd_vel | head -n 10

echo -e "\n✅ LIMO 완전 자율주행 실행 완료!"
