#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>
#include <geometry_msgs/Twist.h>
#include <algorithm>
ros::Publisher pub;
void cb(const sensor_msgs::LaserScan::ConstPtr& s){
  geometry_msgs::Twist c;
  float min=*std::min_element(s->ranges.begin(),s->ranges.end());
  if(min<0.5) c.angular.z=0.6; else c.linear.x=0.25;
  pub.publish(c);
}
int main(int a,char** b){
  ros::init(a,b,"obstacle_avoidance");
  ros::NodeHandle n; pub=n.advertise<geometry_msgs::Twist>("/cmd_vel",10);
  ros::Subscriber sub=n.subscribe("/scan",10,cb);
  ros::spin();
}
