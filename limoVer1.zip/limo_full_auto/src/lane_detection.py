#!/usr/bin/env python3
import rospy, cv2
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
bridge = CvBridge()
def cb(msg):
    frame = bridge.imgmsg_to_cv2(msg, "bgr8")
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 120, 250)
    cv2.imshow("Lane Detection", edges)
    cv2.waitKey(1)
rospy.init_node("lane_detection")
rospy.Subscriber("/usb_cam/image_raw", Image, cb)
rospy.spin()
